# Elitecare App Builder v3 — Free GitHub Actions architecture

## What is included
- A web builder interface (`index.html`)
- GitHub Actions Android build workflow
- AAB/APK/both output
- Java 17 and Gradle cache
- Upload of your Android project ZIP to the selected GitHub repository
- Workflow dispatch from the browser

## Setup
1. Create a GitHub repository, for example `elitecare-app-builder`.
2. Put `index.html` at the repository root.
3. Put `.github/workflows/build-android.yml` in the repository.
4. Push to the `main` branch.
5. Enable Actions if GitHub asks.
6. Open `index.html` through GitHub Pages (Settings > Pages > Deploy from branch > main > /root).
7. Create a fine-grained GitHub token limited to this repository. Give it Contents: Read and write, and Actions: Read and write.
8. Open the builder page and enter the owner, repository and token.
9. Select your Android project ZIP and click BUILD APP.
10. GitHub Actions builds the AAB/APK. Download the artifact from the workflow run.

## Important limits
- GitHub free Actions usage depends on whether the repository is public/private and your account allowance.
- The browser sends the token only for the current page session; do not paste a token into a public file.
- This first version expects a complete Gradle Android project and does not yet generate a project from scratch.

## Next modules
- Automatic release keystore management
- Icon/splash injection
- Onboarding generator
- Bottom navigation generator
- Firebase Cloud Messaging integration
- Build history in a database
